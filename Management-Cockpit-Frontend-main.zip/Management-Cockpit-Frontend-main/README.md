# Management-Cockpit-Frontend
Frontend for HSRT Management Cockpit Wettbewerbsanalyse
