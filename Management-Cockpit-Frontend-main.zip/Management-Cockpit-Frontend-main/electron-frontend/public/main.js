const { app, BrowserWindow } = require('electron')

function createWindows() {
  // We cannot require the screen module until the app is ready.
  const { screen } = require('electron')

  // Create a main window that starts maximized on the primary display
  const primaryDisplay = screen.getPrimaryDisplay()
  const { width, height } = primaryDisplay.workAreaSize
  // TODO: enable web security and add middleware to enable CORS
  mainWindow = new BrowserWindow({ width, height, frame: false, fullscreen: true, show: false, webPreferences: { webSecurity: false }})
  mainWindow.loadURL('http://localhost:3000')
  mainWindow.maximize();
  mainWindow.show();

  // Open the DevTools.
  mainWindow.webContents.openDevTools()

  // TODO: pull all screens, put graph windows on all secondary screens
  const displays = screen.getAllDisplays()
  
  const externalDisplays = displays.filter((display) => {
    return display.bounds.x !== 0 || display.bounds.y !== 0
  })
  console.log(externalDisplays.length);
  externalDisplays.forEach(display => {
    
    win = new BrowserWindow({
      x: display.bounds.x + 50,
      y: display.bounds.y + 50,
      // TODO: enable web security and add middleware to enable CORS
      webPreferences: {
        webSecurity: false
    }
    })
    win.loadURL('https://github.com')
  });
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.whenReady().then(createWindows)

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

app.on('activate', () => {
  // On macOS it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.

  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow()
  }
})

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.
