class GrafanaPanel {
  constructor(id, title, type, description, dashboardUid) {
    this.id = id;
    this.title = title;
    this.type = type;
    this.description = description;
    this.dashboardUid = dashboardUid;
  }
}

module.exports = { GrafanaPanel };