class GrafanaFolder {
  constructor(uid, title) {
    this.uid = uid;
    this.title = title;
  }
}

module.exports = { GrafanaFolder };