class GrafanaDashboard {
  constructor(uid, title) {
    this.uid = uid;
    this.title = title;
  }
}

module.exports = { GrafanaDashboard };