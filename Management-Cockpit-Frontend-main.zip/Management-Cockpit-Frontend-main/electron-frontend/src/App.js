import './App.css';
import PaneDimensions from './pane-dimensions';
const grafanaConnector = require('./connectors/grafana/connector-grafana.js');

function App() {
  return (
      <PaneDimensions fetchTileDimensions={() => grafanaConnector.getGrafanaFolders()}/>
  );
}

export default App;
