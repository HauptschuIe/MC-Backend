import React, { Component } from 'react';
const logo = require('./images/Back.png');

export default class TileDimensionBack extends Component {
    render() {
        return (
            <button className="btn" onClick={() => this.props.onClick()}> <img src={logo}></img> </button>
        )
    }
    
}