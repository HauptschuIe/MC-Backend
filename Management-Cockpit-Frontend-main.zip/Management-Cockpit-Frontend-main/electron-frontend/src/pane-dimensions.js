import TileDimension from './tile-dimension';
import TileDimensionBack from './tile-dimension-backbutton';
import React, { Component } from 'react';

const grafanaConnector = require('./connectors/grafana/connector-grafana.js');

export default class PaneDimensions extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedTileVisualisation: null,
            selectedTileDimension: null,
            selectedTileName:null,
            tileDimensions: [],
        };
    }

    render() {
        const { tileDimensions } = this.state
        return tileDimensions.length ? this.renderTileDimensions() : (
            <span>Loading Dimensions...</span>
          )
    }

    renderTileDimensions() {
        // TODO: create one TileDimension for each element in this.state.tileDimensions
        //var tileDimensionArray = [];
        //this.state.tileDimensions.forEach(dim => {
         //   var tileDimension = document.createElement('TileDimension');
         //   tileDimension.value="Dimension A";
         //   tileDimensionArray.push(tileDimension);
        //});
        
        return (
            <div className='boardsFlex'>
            {this.state.tileDimensions.map((d, idx, {length}) => {
                if(this.state.selectedTileDimension === "Dimension A"){
                    return <TileDimension value={d.title} onClick={() => this.handleClickDimA(d.uid,this.state.selectedTileDimension)}/>
                }else if(this.state.selectedTileDimension === "Dimension B" && length - 1 != idx){
                    return <TileDimension value={d.title} onClick={() => this.handleClickDimB(d.uid)}/>
                }else if (this.state.selectedTileDimension === "Dimension B" && length - 1 === idx){
                    return (<React.Fragment>
                        <TileDimension value={d.title} onClick={() => this.handleClickDimB(d.uid)}/>
                            <TileDimensionBack onClick={() => this.handleBackClick()}/>
                            </React.Fragment>)
                }
            })}
            </div>
        )
    }

    handleBackClick() {
        document.getElementById("boardsFlex").innerHTML = "";
        this.state.selectedTileDimension === "Dimension A" ?  this.state.selectedTileDimension = "Dimension B" : this.state.selectedTileDimension = "Dimension A"
        grafanaConnector.getGrafanaFolders().then(res => this.setState({ tileDimensions: res }) )
    }

    handleClickDimA(name,dimension) {
        dimension === "Dimension A" ?  this.state.selectedTileDimension = "Dimension B" : this.state.selectedTileDimension = "Dimension A"
        grafanaConnector.getGrafanaDashboards(name)
          .then(res => this.setState({ tileDimensions: res }) )
        this.state.selectedTileName = name;
    }

    handleClickDimB(name) {
        document.getElementById("boardsFlex").innerHTML = "";
        this.state.selectedTileName = name;
        grafanaConnector.getGrafanaPanels(name)
          .then(res => this.setState({ selectedTileVisualisation: res },this.createVisualisationsElements) )
    }

    createVisualisationsElements(){
        this.state.selectedTileVisualisation.forEach(dim => {
            const btn = document.createElement("button");
            btn.innerHTML = dim.title;
            btn.classList.add('btn');
            document.getElementById("boardsFlex").appendChild(btn);
        });
    }

    componentDidMount() {
        document.getElementById("boardsFlex").innerHTML = "";
        this.state.selectedTileDimension = "Dimension A";
        this.props.fetchTileDimensions()
          .then(res => this.setState({ tileDimensions: res }) )
      }
}