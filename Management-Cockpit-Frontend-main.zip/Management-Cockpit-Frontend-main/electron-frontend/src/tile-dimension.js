import React, { Component } from 'react';

export default class TileDimension extends Component {
    render() {
        console.log(this.props)
        return (
            
            <button className="btn" onClick={() => this.props.onClick()}> {this.props.value} </button>
        )
    }
}